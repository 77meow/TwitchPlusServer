package com.laioffer.jupiter.entity;

public enum ItemType {
    STREAM, VIDEO, CLIP;
}

// ItemType t = ItemType.STREAM;
// ItemType t = ItemType.Vincent <- error
